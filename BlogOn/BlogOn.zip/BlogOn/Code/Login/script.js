[
  {
    "repositoryUrl": "https://packages.jetbrains.team/maven/p/ij/intellij-redist",
    "artifacts": [
      {
        "groupId": "junit",
        "artifactId": "junit",
        "annotations": {
          "[4.0, 5.0)": {
            "groupId": "org.jetbrains.externalAnnotations.junit",
            "artifactId": "junit",
            "version": "4.12-an1"
          }
        }
      },
      {
        "groupId": "org.hamcrest",
        "artifactId": "hamcrest-core",
        "annotations": {
          "[1.0, 1.3)": {
            "groupId": "org.jetbrains.externalAnnotations.org.hamcrest",
            "artifactId": "hamcrest-core",
            "version": "1.3-an1"
          }
        }
      },
      {
        "groupId": "com.fasterxml.jackson.core",
        "artifactId": "jackson-core",
        "annotations": {
          "[2.0, 3.0)": {
            "groupId": "org.jetbrains.externalAnnotations.com.fasterxml.jackson.core",
            "artifactId": "jackson-core",
            "version": "2.9.6-an1"
          }
        }
      },
      {
        "groupId": "com.fasterxml.jackson.core",
        "artifactId": "jackson-databind",
        "annotations": {
          "[2.0, 3.0)": {
            "groupId": "org.jetbrains.externalAnnotations.com.fasterxml.jackson.core",
            "artifactId": "jackson-databind",
            "version": "2.9.6-an1"
          }
        }
      },
      {
        "groupId": "com.miglayout",
        "artifactId": "miglayout-swing",
        "annotations": {
          "[5.0, 5.1]": {
            "groupId": "org.jetbrains.externalAnnotations.com.miglayout",
            "artifactId": "miglayout-swing",
            "version": "5.1-an1"
          }
        }
      },
      {
        "groupId": "io.netty",
        "artifactId": "netty-buffer",
        "annotations": {
          "[4.0, 4.2)": {
            "groupId": "org.jetbrains.externalAnnotations.io.netty",
            "artifactId": "netty-buffer",
            "version": "4.1.27.Final-an1"
          }
        }
      },
      {
        "groupId": "io.netty",
        "artifactId": "netty-common",
        "annotations": {
          "[4.0, 4.2)": {
            "groupId": "org.jetbrains.externalAnnotations.io.netty",
            "artifactId": "netty-common",
            "version": "4.1.27.Final-an1"
          }
        }
      },
      {
        "groupId": "io.netty",
        "artifactId": "netty-resolver",
        "annotations": {
          "[4.0, 4.2)": {
            "groupId": "org.jetbrains.externalAnnotations.io.netty",
            "artifactId": "netty-resolver",
            "version": "4.1.27.Final-an1"
          }
        }
      },
      {
        "groupId": "io.netty",
        "artifactId": "netty-transport",
        "annotations": {
          "[4.0, 4.2)": {
            "groupId": "org.jetbrains.externalAnnotations.io.netty",
            "artifactId": "netty-transport",
            "version": "4.1.27.Final-an1"
          }
        }
      },
      {
        "groupId": "org.picocontainer",
        "artifactId": "picocontainer",
        "annotations": {
          "[1.0, 1.2]": {
            "groupId": "org.jetbrains.externalAnnotations.org.picocontainer",
            "artifactId": "picocontainer",
            "version": "1.2-an1"
          }
        }
      },
      {
        "groupId": "org.yaml",
        "artifactId": "snakeyaml",
        "annotations": {
          "[1.20, 1.3)": {
            "groupId": "org.jetbrains.externalAnnotations.org.yaml",
            "artifactId": "snakeyaml",
            "version": "1.23-an1"
          }
        }
      }
    ]
  }
]